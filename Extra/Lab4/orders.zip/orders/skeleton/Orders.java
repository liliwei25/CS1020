/**
Name        :
Matric No.  :
PLab Acc.   :
*/

import java.util.*;

public class Orders {
    public void run() {
        // implement your "main" method here
    }

    public static void main(String[] args) {
        Orders o = new Orders();
        o.run();
    }
}
