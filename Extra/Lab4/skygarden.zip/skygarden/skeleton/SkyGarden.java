/**
Name        :
Matric No.  :
PLab Acc.   :
*/

import java.util.*;

public class SkyGarden {
    public void run() {
        // implement your "main" method here
    }

    public static void main(String[] args) {
        SkyGarden sg = new SkyGarden();
        sg.run();
    }
}

class Pair {
    int first;
    int second;

    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }

    public int getFirst() {
        return this.first;
    }

    public int getSecond() {
        return this.second();
    }

    public void setFirst(int newFirst) {
        this.first = newFirst;
    }

    public void setSecond(int newSecond) {
        this.second = newSecond;
    }
}
