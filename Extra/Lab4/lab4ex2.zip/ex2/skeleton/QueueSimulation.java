// CS1020 (AY2014/5 Semester 2)
// Take-home Lab4 Ex2
// Name: 
// Matric. No.: 
// Lab group: 
// Write the program description below.
// It is mandatory to write program description at the top of every program.
// Marks will be awarded for this in sit-in labs.
// Please remove this line and its preceding 3 lines.

import java.util.*;

public class QueueSimulation {
	Node head;
	Node tail;
	int size;
	//declare any additonal attributes here


	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		//Write code to read/process input from console here and print output here
		
	}
	
	public QueueSimulation() {
		//fill in the necessary details you think you will need for the constructor

	}

	
	/*
	Method Description:
	Post Cond:
	Pre Cond:
	*/
	//implement this insert function to add a person who is differentiated by type vip/regular to the queue
	public void insert(int type, String data) {
		
	}

	/*
	Method Description:
	Post Cond:
	Pre Cond:
	*/
	//implement this function to print the entire queue out to console
	public void printQueue() {
		
	}


	/*
	Method Description:
	Post Cond:
	Pre Cond:
	*/
	//implement this function to print the position of the specific user from the front
	public void printSearchUser(String searchUser) {
		
	}

}


class Node {
	private String item; //variable which stores the name of the person in queue
	private int type; //variable to differentiate priority
	private Node prev;
	private Node next;
	//additional attributes here you think you might need


	//default constructor implement any other constructors you deem necessary
	public Node() {
		//implement any details you deem necessary	

	}

	public String getData() { 
		return item; 
	}

	public Node getPrev() { 
		return prev; 
	}
	
	public Node getNext() { 
		return next; 
	}
	
	public int getType() { 
		return type; 
	}
	
	public void setPrev(Node prevNode) { 
		prev = prevNode; 
	}

	public void setNext(Node nextNode) { 
		next = nextNode; 
	}
}

