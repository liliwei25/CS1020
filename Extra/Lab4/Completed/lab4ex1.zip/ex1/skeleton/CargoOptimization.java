// CS1020 (AY2014/5 Semester 2)
// Take-home Lab4 Ex1
// Name: 
// Matric. No.: 
// Lab group: 
// Write the program description below.
// It is mandatory to write program description at the top of every program.
// Marks will be awarded for this in sit-in labs.
// Please remove this line and its preceding 3 lines.

import java.util.*;

public class CargoOptimization {

	private ArrayList<Stack<Container>> stacks; // use an array list to represent the stacks in the terminal
	public CargoOptimization() { stacks = new ArrayList<Stack<Container>>(); }
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CargoOptimization optimizer = new CargoOptimization();

		// complete the program


	}
	
	public int getNumOfStacks() { return stacks.size(); }
	
	// handles each arriving container
	public void processContainer(char ship) {
		
		// complete the method
		
	}

	// returns the index of the best stack to put the container in
	private int findBestStack(Container newArrival) {
		
		return -1; // complete the method
		
	}
}


class Container {
	private char destination;
	public Container(char destination) { this.destination = destination; }

	// method should return compatibility score between this container and the target stack. 
	// they are most compatible when the container at the top of the stack has the same destination as this container
	public int calculateFitWith(Stack<Container> candidate) {

		return -1; // complete the method

	}
}
