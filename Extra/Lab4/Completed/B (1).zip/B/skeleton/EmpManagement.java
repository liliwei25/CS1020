/*
 * CS1020 (AY2013/4 Sem2)
 * Sit-in Lab 3 #B
 * Author    :
 * Matric no.:
 * Lab group :
 * Description of program:
 */

import java.util.*;

/* Service class representing an employee */
class Employee {

}

/* Client class to simulate the employee management system */
public class EmpManagement {

    public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
    }
}
