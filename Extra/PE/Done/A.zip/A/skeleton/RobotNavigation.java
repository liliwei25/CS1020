/*
 * CS1020 (AY2013/4 Sem2)
 * Sit-in Lab 4 #A
 * Author    :
 * Matric no.:
 * Lab group :
 * Description of program:
 */

import java.util.*;

/* class representing the Robot Navigation system */
public class RobotNavigation {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

    }
}
