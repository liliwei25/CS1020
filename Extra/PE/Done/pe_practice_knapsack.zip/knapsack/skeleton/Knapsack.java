/**
 *	name	  :
 *	matric no.:
 */

import java.util.*;

class Result {
    // declare the member field

    // declare the constructor

	/** 
	 *	solve			: to count the number of sets of items satisfying the criteria.
	 * 		  			  (the total weight of all items in a set should not exceed the capacity of the sack)
	 * 	Pre-condition  	:
	 * 	Post-condition 	:
	 */	
	// you should determine the recurrence state(parameters) yourself.
	public int solve() {
		// implementation
		return 0;
	}
}

class Knapsack {

	public static void main(String[] args) {

		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}