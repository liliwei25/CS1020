/**
 * Name			:
 * Matric No.	:
 */
import java.util.*;

public class Love {

	public void run() {
		// treat this as your "main" method
	}

	public static void main(String[] args) {
		Love myLove = new Love();
		myLove.run();
	}

}
