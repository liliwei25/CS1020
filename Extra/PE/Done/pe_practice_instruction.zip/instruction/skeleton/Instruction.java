import java.util.*;

class Instruction {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	}
}
