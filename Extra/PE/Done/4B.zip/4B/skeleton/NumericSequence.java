/*
 * CS1020 (AY2014/5 Sem2)
 * Sit-in Lab 04 B
 * Author      : 
 * Matric no.  : 
 * Lab group   : 
 * Description :
 *      ???
 *      ???
 */

import java.util.Scanner;

public class NumericSequence {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		NumericSequence ns = new NumericSequence();
		ns.find(sc);
    }

    
}

