/**
 *	name	  :
 *	matric no.:
 */

import java.util.*;

class Result {
    // declare the member field

    // declare the constructor

	/**
	 * 	solveMin		: to find the minimum product of triplets.
	 * 	Pre-condition  	:
	 * 	Post-condition 	:
	 */	
	public int solveMin(int[] data) {
		// implementation
		return 0;
	}

	/**
	 *	solveMax		: to find the maximum product of triplets.
	 * 	Pre-condition  	:
	 * 	Post-condition 	:
	 */	
	public int solveMax(int[] data) {
		// implementation
		return 0;
	}
}

public class Triplet {

	public static void main(String[] args) {

		// declare the necessary variables

		// declare a Scanner object to read input

		// read input and process them accordingly
	}
}