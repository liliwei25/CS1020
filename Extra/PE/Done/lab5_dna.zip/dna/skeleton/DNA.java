/**
 *	Name	  :
 *	Matric no.:
 */

import java.util.*;

public class DNA {
    
    // attributes
    
    public void run() {
        // declare the necessary variables
        
        // declare a Scanner object to read input
        
        // read input and process them accordingly
    }
    
    /**
     *	generate		: use this method to generate/pre-process the substrings of length K from DNA
     *	Pre-condition	:
     *	Post-condition	:
     */
    public void generate(String dna) {
        // implementation
    }
    
    /**
     *	count			: use this method to answer one query.
     *	Pre-condition	:
     *	Post-condition	:
     */
    public int count(String substring) {
        // implementation
        return 0;
    }

    public static void main(String[] args) {
        DNA dna = new DNA();
        dna.run();
    }
}
