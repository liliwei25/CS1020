/**
 *  Name          :
 *  Matric Number :
 */

import java.util.*;

public class Pair {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	}
}
